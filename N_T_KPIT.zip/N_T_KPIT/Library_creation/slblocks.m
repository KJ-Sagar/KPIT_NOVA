function blkStruct = slblocks
    Browser.Library = 'MyLibNova';
    Browser.Name = 'ownLibrary';
    blkStruct.Browser = Browser;